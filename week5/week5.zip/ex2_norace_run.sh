sh ex2_norace.sh & 
sh ex2_norace.sh
