sh ex2_race.sh &
sh ex2_race.sh